import * as assert from 'assert/strict';

test('instanceof', () => {
  assert.equal('abc' instanceof String, false);
  assert.equal(null instanceof Object, false);
  assert.equal(undefined instanceof Object, false);
  
  assert.equal([true, false] instanceof Array, true);
  assert.equal([true, false] instanceof Object, true);
  assert.equal({} instanceof Object, true);
});
