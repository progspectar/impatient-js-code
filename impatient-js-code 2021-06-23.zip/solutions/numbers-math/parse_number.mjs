export function parseNumber(str) {
  return Number(str);
}